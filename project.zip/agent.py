from copy import deepcopy
from typing import List

import torch
import torch.nn.functional as F
from torch import nn, Tensor
from torch.optim import Adam
'''
4 networks and util funtions
'''
class Agent:

    def __init__(self,obs_dim,act_dim,global_states_dim,actor_lr,critic_lr,agent_type):
        self.actor_nn=mlp_nn(obs_dim,act_dim)
        self.critic_nn=mlp_nn(global_states_dim,1)
        self.target_actor_nn=deepcopy(self.actor_nn)
        self.target_critic_nn=deepcopy(self.critic_nn)
        # set optimizers for network
        self.actor_opt=Adam(self.actor_nn.parameters(),lr=actor_lr)
        self.critic_opt=Adam(self.critic_nn.parameters(),lr=critic_lr)
        if agent_type:
           self.agent_type=agent_type
        
    '''
    util functions related to networks
    '''
    # take tensor as input 
    def action(self,obs,model_out=False):
        logits=self.actor_nn(obs)
        #action=F.gumbel_softmax(logits,hard=True)
        action = torch.tanh(logits)
        if model_out:
            return action,logits
        return action
      
    # select next_action used in target Q_value
    def target_action(self,obs,model_out=False):
        logits = self.target_actor_nn(obs)  # torch.Size([batch_size, action_size])
        #action = F.gumbel_softmax(logits, hard=True)
        action=torch.tanh(logits)
        return action.squeeze(0)
       
    
    def critic_value(self,obs_list:List[Tensor],act_list:List[Tensor]):
        x=torch.cat(obs_list+act_list,1)
        return self.critic_nn(x).squeeze(1)
    
    def target_critic_value(self,obs_list: List[Tensor],act_list:List[Tensor]):
        x=torch.cat(obs_list+act_list,1)
        return self.target_critic_nn(x).squeeze(1) 
    
    def update_critic(self,loss):
        self.critic_opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic_nn.parameters(), 0.5)
        self.critic_opt.step()
    
    def update_actor(self,loss):
        self.actor_opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor_nn.parameters(), 0.5)
        self.actor_opt.step()

class mlp_nn(nn.Module):
    def __init__(self,in_dim,out_dim,hidden_dim=64,non_linear=nn.ReLU()):
        super(mlp_nn, self).__init__()
        # build network in sequence
        self.net=nn.Sequential(
            nn.Linear(in_dim,hidden_dim),
            non_linear,
            nn.Linear(hidden_dim,hidden_dim),
            non_linear,
            nn.Linear(hidden_dim,out_dim),
            
        ).apply(self.init_weight) # apply paras initialized by init_weights

    @staticmethod
    def init_weight(m):
            gain=nn.init.calculate_gain('relu')
            if isinstance(m,nn.Linear):
                torch.nn.init.xavier_uniform_(m.weight,gain=gain)
                m.bias.data.fill_(0.01)

    def forward(self,x):
            return self.net(x)

