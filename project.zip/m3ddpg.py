import logging
import os 
import pickle

import numpy as np
import torch
import torch.nn.functional as F

from agent import Agent 
from replay_buffer import Buffer


def setup_logger(filename):
    """ set up logger with filename. """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    handler = logging.FileHandler(filename, mode='w')
    handler.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s--%(levelname)s--%(message)s', datefmt='%Y-%m-%d %H:%M:%S')
    handler.setFormatter(formatter)

    logger.addHandler(handler)
    return logger

class M3DDPG:

    def __init__(self,dim_info,capacity,batch_size,actor_lr,critic_lr,res_dir):
        # get a global observation dimension by sum all the dim info of each agent
        global_states_dim=sum(sum(val) for val in dim_info.values())
        # self.good_agents={}
        # self.ad_agents={}
        self.agents={}
        self.buffers={}
        # each agent in env will get its own information dictionary
        for agent_id,(obs_dim,act_dim) in dim_info.items():
            if 'agent' in agent_id:
               self.agents[agent_id]=Agent(obs_dim,act_dim,global_states_dim,actor_lr,critic_lr,'good')
            else:
               self.agents[agent_id]=Agent(obs_dim,act_dim,global_states_dim,actor_lr,critic_lr,'bad')
            self.buffers[agent_id]=Buffer(capacity,obs_dim,act_dim,batch_size,'cpu')
        self.batch_size=batch_size
        self.dim_info=dim_info
        self.res_dir=res_dir
        self.logger = setup_logger(os.path.join(res_dir, 'm3ddpg.log'))
        
    # do this every env.step()
    def add_to_buffer(self,obs,act,reward,next_obs,done):
        for agent_id in obs.keys():
            a=act[agent_id]
            if isinstance(act[agent_id],int):
                a=np.eye(self.dim_info[agent_id][1])[act[agent_id]]

            self.buffers[agent_id].add_exp(obs[agent_id],a,reward[agent_id],next_obs[agent_id],done[agent_id])

    # do this when we need to learn
    def sample_from_buffer(self):
        obs, act, reward, next_obs, done={}, {}, {}, {}, {}
        for agent_id, buffer in self.buffers.items():
            o, a, r, n_o, d = buffer.sample_exp()
            obs[agent_id]=o
            act[agent_id]=a
            reward[agent_id]=r
            next_obs[agent_id]=n_o
            done[agent_id]=d
        
        return obs,act,reward,next_obs,done
        
    # decentralized act of each agent
    def select_action(self,obs):
        actions={} 
        for agent_id,o in obs.items():
            # convert numpy to tensor
            o=torch.from_numpy(o).unsqueeze(0).float()
            a=self.agents[agent_id].action(o)
            # return action with maximum pv
            actions[agent_id]=a.squeeze(0).argmax().item()
        return actions
 
    '''
         implement of m3ddpg features

    '''
    def learn(self,gamma):
        agent_id_list=[]
        agent_list=[]
        for agent_id,agent in self.agents.items():
            agent_id_list.append(agent_id)
            agent_list.append(agent)
        obs_n_batch,act_n_batch,reward_n_batch,next_obs_n_batch,dones_n_batch=self.sample_from_buffer()
        for i,agent_id in enumerate(agent_id_list):
            
            if  'good' == self.agents[agent_id].agent_type:
                eps=1e-3
            else:
                eps=1e-5
            

            reward=reward_n_batch[agent_id]
            done= dones_n_batch[agent_id]
            
            _next_actions=[self.agents[agent_id_list[j]].target_action(next_obs_n_batch[agent_id_list[j]]) for j in range(len(self.agents))]
            for _next_action in _next_actions :
                _next_action.requires_grad_(True)
                _next_action.retain_grad()
            _next_action_n_batch_critic = torch.cat([_next_action if j != i else _next_action.detach() for j, _next_action in enumerate(_next_actions)],axis=1).unsqueeze(0)
            _critic_target_loss= self.agents[agent_id].target_critic_value(list(next_obs_n_batch.values()),list(_next_action_n_batch_critic)).mean()
            _critic_target_loss.backward(retain_graph=True)
            
            with torch.no_grad():
                next_action_n_batch_critic=torch.cat(
                    [_next_action + torch.tensor(eps) * _next_action.grad if j != i else _next_action for j, _next_action in enumerate(_next_actions)],1
                ).unsqueeze(0)
            _next_action.detach()

            _actions= [self.agents[agent_id_list[j]].action(obs_n_batch[agent_id_list[j]]) for j in range(len(self.agents))]

            for _action in _actions :
                _action.requires_grad_(True)
                _action.retain_grad()
            _action_n_batch_actor= torch.cat([_action if j!= i else _action.detach() for j,_action in enumerate(_actions)],1).unsqueeze(0)
            
            _actor_target_loss = self.agents[agent_id].critic_value(list(obs_n_batch.values()),list(_action_n_batch_actor)).mean()
            _actor_target_loss.backward(retain_graph=True)
            action_n_batch_actor=torch.cat(
                [_action + eps* _action.grad if j!= i else _action for j, _action in enumerate(_actions)],1).unsqueeze(0)
            _action.detach()
            #update critic network
            critic_value=self.agents[agent_id].critic_value(list(obs_n_batch.values()),list(act_n_batch.values()))
            next_critic_value=self.agents[agent_id].target_critic_value(list(next_obs_n_batch.values()),list(next_action_n_batch_critic))
            target_value=reward+gamma*(1-done)*next_critic_value
            critic_loss=F.mse_loss(critic_value,target_value)
            self.agents[agent_id].update_critic(critic_loss)

            # update actor network
            actor_loss=-self.agents[agent_id_list[i]].critic_value(list(obs_n_batch.values()),list(action_n_batch_actor)).mean()
            self.agents[agent_id].update_actor(actor_loss)


    
    def update_target(self, tau):
        def soft_update(from_network, to_network):
            """ copy the parameters of `from_network` to `to_network` with a proportion of tau"""
            for from_p, to_p in zip(from_network.parameters(), to_network.parameters()):
                to_p.data.copy_(tau * from_p.data + (1.0 - tau) * to_p.data)

        for agent in self.agents.values():
            soft_update(agent.actor_nn, agent.target_actor_nn)
            soft_update(agent.critic_nn, agent.target_critic_nn)

    # 在结果目录下保存模型参数和agent参数
    def save(self, reward):
        """save actor parameters of all agents and training reward to `res_dir`"""
        torch.save(
            {name: agent.actor_nn.state_dict() for name, agent in self.agents.items()},  # actor parameter
            os.path.join(self.res_dir, 'model.pt')
        )
        with open(os.path.join(self.res_dir, 'rewards.pkl'), 'wb') as f:  # save training data
            pickle.dump({'rewards': reward}, f)

    @classmethod
    def load(cls, dim_info, file):
        """init m3ddpg using the model saved in `file`"""
        instance = cls(dim_info, 0, 0, 0, 0, os.path.dirname(file))
        data = torch.load(file)
        for agent_id, agent in instance.agents.items():
            agent.actor_nn.load_state_dict(data[agent_id])
        return instance

        




   

