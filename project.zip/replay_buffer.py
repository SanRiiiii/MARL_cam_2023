import numpy as np
import torch

'''
intro
-------------
implements exp replay buffers
implements interface between buffers and agents
exps are saved as (obs,act,reward,next_obs,done)
each time updating networks, we sample a batch of exps from buffers to update args


pros
-------------
make the updates uncorrelated
reuse collected exp many times

func declaration
-------------
 def _init_(self,capacity,obs_dim,act_dim,batch_size,device)
 def add_exp(self,obs,act,reward,next_obs,done)
 def sample_exp(self)
'''
class Buffer:

    def __init__(self,capacity,obs_dim,act_dim,batch_size,device):
        self.capacity=capacity
        self.obs=np.zeros((capacity,obs_dim))
        self.act=np.zeros((capacity,act_dim))
        self.reward=np.zeros((capacity))
        self.next_obs=np.zeros((capacity,obs_dim))
        self.done=np.zeros(capacity,dtype=bool)

        self.batch_size=batch_size
        self.device=device # cpu 

        self._index=0
        self._size=0

     

    # public method, can be called outside the class, usually used in m3ddpg section
    def add_exp(self,obs,act,reward,next_obs,done):
        self.obs[self._index]=obs
        self.act[self._index]=act
        self.reward[self._index]=reward
        self.next_obs[self._index]=next_obs
        self.done[self._index]=done
        
        self._index=(self._index+1) %self.capacity # recursive buffer
        if self._size < self.capacity: # if not full
           self._size += 1

    
    def sample_exp(self): #randomly sample a batch of exps
        #  sample exps in amount of batch_size from range of _size
        batch=np.random.choice(self._size,self.batch_size,replace=True)
        # all the variable are nd-array
        obs=self.obs[batch]
        act=self.act[batch]
        reward=self.reward[batch]
        next_obs=self.next_obs[batch]
        done=self.done[batch]
        # convert nd-array to torch tensor
        # so that they can be passed to nn
        obs=torch.from_numpy(obs).float().to(self.device)
        act=torch.from_numpy(act).float().to(self.device)
        reward=torch.from_numpy(reward).float().to(self.device)
        next_obs=torch.from_numpy(next_obs).float().to(self.device)
        done=torch.from_numpy(done).float().to(self.device)

        return obs,act,reward,next_obs,done
    
    def __len__(self):
        return self._size

    









  


                
   




        

  



        
        